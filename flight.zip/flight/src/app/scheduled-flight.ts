import { Flight } from './flight';
import { Schedule } from './schedule';

export class ScheduledFlight {
    availableSeats:number;
    flight:Flight;
    Schedule:Schedule;
    
}
