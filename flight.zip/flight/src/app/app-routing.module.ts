import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddFlightComponent } from './add-flight/add-flight.component';
import {UpdateflightComponent} from './updateflight/updateflight.component';
import {DeleteflightComponent} from './deleteflight/deleteflight.component';
import{ViewallflightComponent} from './viewallflight/viewallflight.component';
import { HomeComponent } from './home/home.component';
import{ViewByIDComponent} from './view-by-id/view-by-id.component';
const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch: 'full'},
  {path: 'home',component:HomeComponent},
  {path:'addflight', component:AddFlightComponent},
  {path:'updateflight', component:UpdateflightComponent},
  {path:'deleteflight', component:DeleteflightComponent},
  {path:'viewallflight', component:ViewallflightComponent},
  {path:'view-by-id',component:ViewByIDComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
