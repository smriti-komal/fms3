import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddFlightComponent } from './add-flight/add-flight.component';
import { ViewallflightComponent } from './viewallflight/viewallflight.component';
import { DeleteflightComponent } from './deleteflight/deleteflight.component';
import { UpdateflightComponent } from './updateflight/updateflight.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { ViewByIDComponent } from './view-by-id/view-by-id.component';

@NgModule({
  declarations: [
    AppComponent,
    AddFlightComponent,
    ViewallflightComponent,
    DeleteflightComponent,
    UpdateflightComponent,
    HomeComponent,
    ViewByIDComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
