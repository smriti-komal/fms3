import { User1 } from './user1';
import { Passenger } from './passenger';

export class Booking {
    bookingId:number;
    ticketCost:number;
    noOfPassengers:number;
    user1:User1;
    passengerList:Passenger;
    

}
