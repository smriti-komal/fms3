import { Component, OnInit } from '@angular/core';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';
@Component({
  selector: 'app-view-by-id',
  templateUrl: './view-by-id.component.html',
  styleUrls: ['./view-by-id.component.css']
})
export class ViewByIDComponent implements OnInit {

  flight:Flight;
  flightNumber:number;
 
  constructor(private flightService:FlightService) { }

  ngOnInit(): void {
  }
  viewByID(){
    console.log(this.flightNumber);
    this.flightService.viewByID(this.flightNumber).subscribe((data)=>{
      data = JSON.parse(data);
      if (data != null){
        this.flight = data as  Flight;
        console.log(this.flight.carrierName);
      } else {
        alert("flight number is not valid");
       }
      });
      
  }
}
