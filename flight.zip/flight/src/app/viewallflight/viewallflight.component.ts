import { Component, OnInit } from '@angular/core';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';
@Component({
  selector: 'app-viewallflight',
  templateUrl: './viewallflight.component.html',
  styleUrls: ['./viewallflight.component.css']
})
export class ViewallflightComponent implements OnInit {

  flight:Flight[]=[];
  constructor(private flightService:FlightService) { }
 

  ngOnInit(): void {
    console.log("Am inside view component");
    this.flightService.viewAllflight().subscribe(data=>this.flight=data);
    console.log(this.flight);
  }
  
}
