import { Booking } from './booking';

export class Passenger {
    prnNumber:number;
    passengerName:string;
    passengerAge:number;
    passengerUIN:number;
    Luggage:number;
    booking:Booking;

}
