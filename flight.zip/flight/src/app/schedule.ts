import { Airport } from './airport';

export class Schedule {
    schedule_id:number;
    sourceAirport:Airport;
    destinationAirport:Airport;
    arrivalDate:Date;
    departureDate:Date;
    
}
