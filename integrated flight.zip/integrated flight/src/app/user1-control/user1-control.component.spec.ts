import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { User1ControlComponent } from './user1-control.component';

describe('User1ControlComponent', () => {
  let component: User1ControlComponent;
  let fixture: ComponentFixture<User1ControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ User1ControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(User1ControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
