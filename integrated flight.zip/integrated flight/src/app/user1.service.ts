import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User1 } from './user1'

@Injectable({
  providedIn: 'root'
})
export class User1Service {
  constructor(private http:HttpClient) { }

  public addUser1(User1:User1):Observable<any>{
    return this.http.post("http://localhost:8890/addUser1",User1,{responseType:'text'});
  }
  public deleteUser1(userId:number):Observable<any>{
    console.log("inside delete service "+userId );
    return this.http.delete(`http://localhost:8890/deleteUser1/${userId}`,{responseType:'text'});
  }
  public updateUser1(User1:User1):Observable<any>{
    return this.http.put(`http://localhost:8890/updateUser1/${User1.userId}`,User1,{responseType:'text'});
  }
  public viewallUser1():Observable<any>{
    console.log("Am inside service");
    return this.http.get("http://localhost:8890/viewallUser1");
  }
  public viewById(userId:number):Observable<any>{
    return this.http.get(`http://localhost:8890/getUser1details/${userId}`,{responseType:'text'});
  }
}