import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Scheduledflight } from './scheduledflight';
import { Flight } from './flight';

@Injectable({
  providedIn: 'root'
})
export class ScheduledflightService {

  constructor(private http:HttpClient) { }

  public viewAllscheduledflight():Observable<any>{
    console.log(" Am inside service ");
    return this.http.get("http://localhost:8890/viewallscheduledflight");
  }

  public addScheduledFlight(scheduledflight:Scheduledflight):Observable<any>{
    return this.http.post("http://localhost:8890/addscheduledflight",scheduledflight,{responseType:'arraybuffer'});
  }

  public deleteScheduledFlight(availableSeats:number):Observable<any>{
    console.log("inside delete service" + availableSeats);
    return this.http.delete(`http://localhost:8890/deletescheduledflight/${availableSeats}`,{responseType:'text'});
  }

  public modifyScheduledFlight(scheduledflight:Scheduledflight):Observable<any>{
    return this.http.put(`http://localhost:8890/modifyscheduledflight/${scheduledflight.availableSeats}`,scheduledflight,{responseType:'text'});
  }
  public viewById(availableSeats:number):Observable<any>{
    return this.http.get(`http://localhost:8890/getscheduledflightdetails/${availableSeats}`,{responseType:'text'});
  }
}
