import { Component, OnInit } from '@angular/core';
import { Flight } from '../../flight';
import { FlightService } from '../../flight.service';
@Component({
  selector: 'app-updateflight',
  templateUrl: './updateflight.component.html',
  styleUrls: ['./updateflight.component.css']
})
export class UpdateflightComponent implements OnInit {

  flight:Flight=new Flight();
  
  constructor(private flightService:FlightService) { }
 

  ngOnInit(): void {
  }

  updateFlight(){
    this.flightService.updateFlight(this.flight).subscribe((data)=>{
      console.log("data",data);
      
      this.flight=new Flight()},
      error=>{alert("Invalid flight number");});
  }

}
