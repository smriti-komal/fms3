import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallflightComponent } from './viewallflight.component';

describe('ViewallflightComponent', () => {
  let component: ViewallflightComponent;
  let fixture: ComponentFixture<ViewallflightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallflightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallflightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
