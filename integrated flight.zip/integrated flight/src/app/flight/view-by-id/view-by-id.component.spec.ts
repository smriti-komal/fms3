import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewByIDComponent } from './view-by-id.component';

describe('ViewByIDComponent', () => {
  let component: ViewByIDComponent;
  let fixture: ComponentFixture<ViewByIDComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewByIDComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewByIDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
