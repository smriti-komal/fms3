import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedule-control',
  templateUrl: './schedule-control.component.html',
  styleUrls: ['./schedule-control.component.css']
})
export class ScheduleControlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
