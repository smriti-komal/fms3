import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyscheduledflightComponent } from './modifyscheduledflight.component';

describe('ModifyscheduledflightComponent', () => {
  let component: ModifyscheduledflightComponent;
  let fixture: ComponentFixture<ModifyscheduledflightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifyscheduledflightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyscheduledflightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
