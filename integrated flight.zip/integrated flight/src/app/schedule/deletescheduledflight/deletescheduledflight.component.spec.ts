import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletescheduledflightComponent } from './deletescheduledflight.component';

describe('DeletescheduledflightComponent', () => {
  let component: DeletescheduledflightComponent;
  let fixture: ComponentFixture<DeletescheduledflightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeletescheduledflightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletescheduledflightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
