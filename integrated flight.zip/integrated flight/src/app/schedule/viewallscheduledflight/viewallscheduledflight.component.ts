import { Component, OnInit } from '@angular/core';
import { Scheduledflight } from '../../scheduledflight';
import { ScheduledflightService } from '../../scheduledflight.service';
@Component({
  selector: 'app-viewallscheduledflight',
  templateUrl: './viewallscheduledflight.component.html',
  styleUrls: ['./viewallscheduledflight.component.css']
})
export class ViewallscheduledflightComponent implements OnInit {

  scheduledflight:Scheduledflight[]=[];
  constructor(private scheduledflightService:ScheduledflightService) { }

  ngOnInit(): void {
    console.log(" Am inside view component");
    this.scheduledflightService.viewAllscheduledflight().subscribe(data=>this.scheduledflight=data);
    console.log(this.scheduledflight);
  }

}
