import { Component, OnInit } from '@angular/core';
import { Scheduledflight } from '../../scheduledflight';
import { ScheduledflightService } from '../../scheduledflight.service';
@Component({
  selector: 'app-addscheduledflight',
  templateUrl: './addscheduledflight.component.html',
  styleUrls: ['./addscheduledflight.component.css']
})
export class AddscheduledflightComponent implements OnInit {
  scheduledflight:Scheduledflight=new Scheduledflight();
  // flightNumber:number;
  // flightModel:string;
  // carrierName:string;
  // seatCapacity:number;
  // schedule_id:number;
  // sourceAirport:string;
  // destinationAirport:string;
  // arrivalDate:Date;
  // departureDate:Date;
  msg:string;
  errormsg:string;
  constructor(private scheduledflightservice:ScheduledflightService) {}

  ngOnInit(): void {
  }

  addScheduledFlight(){
    this.scheduledflightservice.addScheduledFlight(this.scheduledflight).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errormsg=undefined;
      this.scheduledflight=new Scheduledflight()},
      error=>{alert("Invalid Details");});
      // this.scheduledflight=new Scheduledflight();
      // JSON.stringify(this.scheduledflight)},
      // error=>{this.errormsg=JSON.parse(error.error).message;
      // console.log(error.error);
      // this.msg=undefined});
  }

}
