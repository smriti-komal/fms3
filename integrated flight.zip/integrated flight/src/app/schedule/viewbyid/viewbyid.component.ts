import { Component, OnInit } from '@angular/core';
import { Scheduledflight } from '../../scheduledflight';
import { ScheduledflightService } from '../../scheduledflight.service';

@Component({
  selector: 'app-viewbyid',
  templateUrl: './viewbyid.component.html',
  styleUrls: ['./viewbyid.component.css']
})
export class ViewbyidComponent implements OnInit {

  scheduledflight:Scheduledflight;
  availableSeats:number;

  constructor(private scheduledflightservice:ScheduledflightService) { }

  ngOnInit(): void {
  }
  viewById(){
    console.log(this.availableSeats);
    this.scheduledflightservice.viewById(this.availableSeats).subscribe((data)=>{
      data = JSON.parse(data);
      if(data != null){
        this.scheduledflight = data as Scheduledflight;
        console.log(this.scheduledflight.availableSeats);
      }
      else{
        alert("Scheduled Flight is not available");
      }
    });
  }

}
