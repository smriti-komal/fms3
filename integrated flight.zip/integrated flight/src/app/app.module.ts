import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddFlightComponent } from './flight/add-flight/add-flight.component';
import {UpdateflightComponent} from './flight/updateflight/updateflight.component';
import {DeleteflightComponent} from './flight/deleteflight/deleteflight.component';
import{ViewallflightComponent} from './flight/viewallflight/viewallflight.component';
import { HomeComponent } from './home/home.component';
import{ViewByIDComponent} from './flight/view-by-id/view-by-id.component';
import { AddairportComponent} from './airport/addairport/addairport.component';
import { ViewallairportComponent } from './airport/viewallairport/viewallairport.component';
import { UpdateairportComponent } from './airport/updateairport/updateairport.component';
import { DeleteairportComponent } from './airport/deleteairport/deleteairport.component';
import { AirportdetailsComponent } from './airport/airportdetails/airportdetails.component';
import { ViewallbookingComponent } from './booking/viewallbooking/viewallbooking.component';
import { DeletebookingComponent } from './booking/deletebooking/deletebooking.component';
import { UpdatebookingComponent } from './booking/updatebooking/updatebooking.component';
import { AddbookingComponent } from './booking/addbooking/addbooking.component';
import { ViewallscheduledflightComponent } from './schedule/viewallscheduledflight/viewallscheduledflight.component';
import { DeletescheduledflightComponent } from './schedule/deletescheduledflight/deletescheduledflight.component';
import { ModifyscheduledflightComponent } from './schedule/modifyscheduledflight/modifyscheduledflight.component';
import { AddscheduledflightComponent } from './schedule/addscheduledflight/addscheduledflight.component';
import { ViewbyidComponent } from './schedule/viewbyid/viewbyid.component';
import { AddUser1Component } from './user1/add-user1/add-user1.component';
import {UpdateUser1Component} from './user1/update-user1/update-user1.component';
import {DeleteUser1Component} from './user1/delete-user1/delete-user1.component';
import{ViewallUser1Component} from './user1/viewall-user1/viewall-user1.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewbyuseridComponent } from './user1/viewbyid/viewbyid.component';
import { AdminControlComponent } from './admin-control/admin-control.component';
import { UserControlComponent } from './user-control/user-control.component';
import { FlightControlComponent } from './flight-control/flight-control.component';
import { AirportControlComponent } from './airport-control/airport-control.component';
import { User1ControlComponent } from './user1-control/user1-control.component';
import { ScheduleControlComponent } from './schedule-control/schedule-control.component';
import { BookingControlComponent } from './booking-control/booking-control.component';


@NgModule({
  declarations: [
    AppComponent,
    AddFlightComponent,
    ViewallflightComponent,
    DeleteflightComponent,
    UpdateflightComponent,
    HomeComponent,
    ViewByIDComponent,
    AddairportComponent,
    AirportdetailsComponent,
    DeleteairportComponent,
    UpdateairportComponent,
    ViewallairportComponent,
    DeletebookingComponent,
    AddbookingComponent,
    UpdatebookingComponent,
    ViewallbookingComponent,
    ViewallscheduledflightComponent,
    DeletescheduledflightComponent,
    ModifyscheduledflightComponent,
    AddscheduledflightComponent,
    ViewbyidComponent,
    AddUser1Component,
    DeleteUser1Component,
    UpdateUser1Component,
    ViewallUser1Component,
    ViewbyuseridComponent,
    AdminControlComponent,
    UserControlComponent,
    FlightControlComponent,
    AirportControlComponent,
    User1ControlComponent,
    ScheduleControlComponent,
    BookingControlComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
