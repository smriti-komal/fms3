import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Booking } from './booking';
import { Flight } from './flight';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private Http:HttpClient) { }

  public deletebooking(bookingId:number):Observable<any>{ 
    
    return this.Http.delete("http://localhost:8890/deletebooking/"+bookingId, {responseType:'text'});
  }

  public viewallbooking():Observable<any>{
    
    return this.Http.get("http://localhost:8890/viewallbooking");
  }
  public addbooking(booking:Booking):Observable<any>{
    return this.Http.post("http://localhost:8890/addbooking",booking,{responseType:'text'});
  }

  
public updatebooking(booking:Booking):Observable<any>{
  return this.Http.put("http://localhost:8890/updatebooking/",booking,{responseType:'text'});
}
}

