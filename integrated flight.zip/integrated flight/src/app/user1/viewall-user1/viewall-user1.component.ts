import { Component, OnInit } from '@angular/core';
import {User1 } from '../../user1';
import { User1Service } from '../../user1.service'; 

@Component({
  selector: 'app-viewall-user1',
  templateUrl: './viewall-user1.component.html',
  styleUrls: ['./viewall-user1.component.css']
})
export class ViewallUser1Component implements OnInit {
  User1:User1[]=[];

  constructor(private User1Service:User1Service) { }

  ngOnInit(): void {
    console.log("Am inside view component");
    this.User1Service.viewallUser1().subscribe(data=>this.User1=data);
    console.log(this.User1);
  }

}
