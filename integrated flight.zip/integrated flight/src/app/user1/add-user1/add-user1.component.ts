import { Component, OnInit } from '@angular/core';
import {User1 } from '../../user1';
import { User1Service } from '../../user1.service';

@Component({
  selector: 'app-add-user1',
  templateUrl: './add-user1.component.html',
  styleUrls: ['./add-user1.component.css']
})
export class AddUser1Component implements OnInit {
  User1:User1=new User1();
  msg:String;
  errorMsg:String;

  constructor(private User1Service:User1Service) { }

  ngOnInit(): void {
  }
  addUser1(){
    this.User1Service.addUser1(this.User1).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.User1=new User1()},
      error=>{alert("Invalid Details");});

}
}