import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirportControlComponent } from './airport-control.component';

describe('AirportControlComponent', () => {
  let component: AirportControlComponent;
  let fixture: ComponentFixture<AirportControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirportControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirportControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
