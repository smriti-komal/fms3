import { Component, OnInit } from '@angular/core';
import { Booking } from '../../booking';
import { BookingService } from '../../booking.service';

@Component({
  selector: 'app-viewallbooking',
  templateUrl: './viewallbooking.component.html',
  styleUrls: ['./viewallbooking.component.css']
})
export class ViewallbookingComponent implements OnInit {
  bookings:Booking[]=[];
  //booking:Booking=new Booking();
  constructor(private BookingService:BookingService) { }

  ngOnInit(): void {
    console.log("inside view component");
    this.BookingService.viewallbooking().subscribe(data=>this.bookings=data);
    console.log(this.bookings);
  }

}

