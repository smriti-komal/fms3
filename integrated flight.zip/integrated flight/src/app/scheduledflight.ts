import { Flight } from './flight';
import { Schedule } from './schedule';

export class Scheduledflight {
    availableSeats:number;
    flight:Flight = new Flight();
    schedule:Schedule = new Schedule();


    constructor(){
        //this.flightNumber-this.flight.flightNumber;
    }

    // flightNumber:Flight;
    // flightModel:Flight;
    // carrierName:Flight;
    // seatCapacity:Flight;
    // schedule_id:Schedule;
    // sourceAirport:Schedule;
    // destinationAirport:Schedule;
    // arrivalDate:Schedule;
    // departureDate:Schedule;
}
