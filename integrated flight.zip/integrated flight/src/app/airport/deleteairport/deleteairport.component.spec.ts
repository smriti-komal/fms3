import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteairportComponent } from './deleteairport.component';

describe('DeleteairportComponent', () => {
  let component: DeleteairportComponent;
  let fixture: ComponentFixture<DeleteairportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteairportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteairportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
