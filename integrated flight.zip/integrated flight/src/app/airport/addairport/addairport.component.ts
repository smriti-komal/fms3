import { Component, OnInit } from '@angular/core';
import { Airport } from '../../airport';
import { AirportService } from '../../airport.service';

@Component({
  selector: 'app-addairport',
  templateUrl: './addairport.component.html',
  styleUrls: ['./addairport.component.css']
})
export class AddairportComponent implements OnInit {
  airport: Airport = new Airport();
  messege: string;
  errormessege: string;

  constructor(private airportservice: AirportService) { }

  ngOnInit(): void {
  }
  addairport()
  {
    this.airportservice.addairport(this.airport).subscribe((data) => {
      console.log( 'data' , data);
      this.messege = data;
      this.errormessege = undefined;
      this.airport = new Airport(); },
      error => {alert('Invalid Details'); });
  }

}

