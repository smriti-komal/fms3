import { Component, OnInit } from '@angular/core';
import { Airport } from '../../airport';
import { AirportService } from '../../airport.service';
@Component({
  selector: 'app-airportdetails',
  templateUrl: './airportdetails.component.html',
  styleUrls: ['./airportdetails.component.css']
})
export class AirportdetailsComponent implements OnInit {

  airport: Airport;
  airportCode: string;
  constructor(private airportservice: AirportService) { }

  ngOnInit(): void {
  }
  airportdetails()
  {
    console.log(this.airportCode);
    this.airportservice.airportdetails(this.airportCode).subscribe((data) => {
      data = JSON.parse(data);
      if (data != null){
        this.airport = data as Airport;
        console.log(this.airport.airportName);
      }
      else{
        alert('airportCode is not valid');
      }
    });
  }

}
