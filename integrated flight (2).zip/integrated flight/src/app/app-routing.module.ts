import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddFlightComponent } from './flight/add-flight/add-flight.component';
import {UpdateflightComponent} from './flight/updateflight/updateflight.component';
import {DeleteflightComponent} from './flight/deleteflight/deleteflight.component';
import{ViewallflightComponent} from './flight/viewallflight/viewallflight.component';
import { HomeComponent } from './home/home.component';
import{ViewByIDComponent} from './flight/view-by-id/view-by-id.component';
import { AddairportComponent} from './airport/addairport/addairport.component';
import { ViewallairportComponent } from './airport/viewallairport/viewallairport.component';
import { UpdateairportComponent } from './airport/updateairport/updateairport.component';
import { DeleteairportComponent } from './airport/deleteairport/deleteairport.component';
import { AirportdetailsComponent } from './airport/airportdetails/airportdetails.component';
import { ViewallbookingComponent } from './booking/viewallbooking/viewallbooking.component';
import { DeletebookingComponent } from './booking/deletebooking/deletebooking.component';
import { UpdatebookingComponent } from './booking/updatebooking/updatebooking.component';
import { AddbookingComponent } from './booking/addbooking/addbooking.component';
import { ViewallscheduledflightComponent } from './schedule/viewallscheduledflight/viewallscheduledflight.component';
import { DeletescheduledflightComponent } from './schedule/deletescheduledflight/deletescheduledflight.component';
import { ModifyscheduledflightComponent } from './schedule/modifyscheduledflight/modifyscheduledflight.component';
import { AddscheduledflightComponent } from './schedule/addscheduledflight/addscheduledflight.component';

import { AddUser1Component } from './user1/add-user1/add-user1.component';
import {UpdateUser1Component} from './user1/update-user1/update-user1.component';
import {DeleteUser1Component} from './user1/delete-user1/delete-user1.component';
import{ViewallUser1Component} from './user1/viewall-user1/viewall-user1.component';
import{ViewbyuseridComponent} from './user1/viewbyuserid/viewbyuserid.component';
import{UserControlComponent} from './user-control/user-control.component';
import{ScheduleControlComponent} from './schedule-control/schedule-control.component';
import{AirportControlComponent} from './airport-control/airport-control.component';
import{BookingControlComponent} from './booking-control/booking-control.component';
import{FlightControlComponent} from './flight-control/flight-control.component';
import{AdminControlComponent} from './admin-control/admin-control.component';
import{User1ControlComponent} from './user1-control/user1-control.component';
import{ViewbyidavailableseatsComponent} from './schedule/viewbyidavailableseats/viewbyidavailableseats.component';
const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch: 'full'},
  {path: 'home',component:HomeComponent},
  {path:'addflight', component:AddFlightComponent},
  {path:'updateflight', component:UpdateflightComponent},
  {path:'deleteflight', component:DeleteflightComponent},
  {path:'viewallflight', component:ViewallflightComponent},
  {path:'view-by-id',component:ViewByIDComponent},
  {path: 'airportdetails', component: AirportdetailsComponent},
  {path: 'deleteairport', component: DeleteairportComponent},
  {path: 'addairport', component: AddairportComponent},
  {path: 'viewallairport', component: ViewallairportComponent},
  {path: 'updateairport', component: UpdateairportComponent},
  {path:'deletebooking',component:DeletebookingComponent},
  {path:'viewallbooking',component:ViewallbookingComponent},
  {path:'updatebooking',component:UpdatebookingComponent},
  {path:'addbooking',component:AddbookingComponent},
  {path:'deletescheduledflight',component:DeletescheduledflightComponent},
  {path:'modifyscheduledflight',component:ModifyscheduledflightComponent},
  {path:'viewallscheduledflight',component:ViewallscheduledflightComponent},
  {path:'addscheduledflight',component:AddscheduledflightComponent},

  {path:'add-user1', component:AddUser1Component},
  {path:'delete-user1', component:DeleteUser1Component},
  {path:'update-user1', component:UpdateUser1Component},
  {path:'viewall-user1', component:ViewallUser1Component},
  {path:'viewbyuserid',component:ViewbyuseridComponent},
  {path:'user-control', component:UserControlComponent},
  {path:'schedule-control',component:ScheduleControlComponent},
  {path:'airport-control',component:AirportControlComponent},
  {path:'booking-control',component:BookingControlComponent},
  {path:'flight-control',component:FlightControlComponent},
  {path:'admin-control',component:AdminControlComponent},
  {path:'user1-control', component:User1ControlComponent},
  {path: 'viewbyidavailableseats',component:ViewbyidavailableseatsComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
