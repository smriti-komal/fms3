import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-control',
  templateUrl: './booking-control.component.html',
  styleUrls: ['./booking-control.component.css']
})
export class BookingControlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
