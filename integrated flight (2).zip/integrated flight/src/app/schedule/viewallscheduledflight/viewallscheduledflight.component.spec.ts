import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallscheduledflightComponent } from './viewallscheduledflight.component';

describe('ViewallscheduledflightComponent', () => {
  let component: ViewallscheduledflightComponent;
  let fixture: ComponentFixture<ViewallscheduledflightComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallscheduledflightComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallscheduledflightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
