import { Component, OnInit } from '@angular/core';
import { Scheduledflight } from '../../scheduledflight';
import { ScheduledflightService } from '../../scheduledflight.service';

@Component({
  selector: 'app-modifyscheduledflight',
  templateUrl: './modifyscheduledflight.component.html',
  styleUrls: ['./modifyscheduledflight.component.css']
})
export class ModifyscheduledflightComponent implements OnInit {

  scheduledflight:Scheduledflight=new Scheduledflight();
  msg:String;
  errorMsg:String;
  constructor(private scheduledflightService:ScheduledflightService) { }

  ngOnInit(): void {
  }

  modifyScheduledFlight(){
    this.scheduledflightService.modifyScheduledFlight(this.scheduledflight).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.scheduledflight=new Scheduledflight()},
      error=>{alert("Invalid Modification");});
      // error=>{this.errorMsg=JSON.parse(error.error).message;
      // console.log(error.error);
      // this.msg=undefined});
  }

}
