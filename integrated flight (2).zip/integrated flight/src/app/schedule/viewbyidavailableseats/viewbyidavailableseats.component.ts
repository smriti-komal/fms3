import { Component, OnInit } from '@angular/core';
import { Scheduledflight } from '../../scheduledflight';
import { ScheduledflightService } from '../../scheduledflight.service';

@Component({
  selector: 'app-viewbyidavailableseats',
  templateUrl: './viewbyidavailableseats.component.html',
  styleUrls: ['./viewbyidavailableseats.component.css']
})
export class ViewbyidavailableseatsComponent implements OnInit {

  scheduledflight:Scheduledflight;
  availableSeats:number;

  constructor(private scheduledflightservice:ScheduledflightService) { }

  ngOnInit(): void {
  }
  viewByIDavailableseats(){
    console.log(this.availableSeats);
    this.scheduledflightservice.viewByIDavailableseats(this.availableSeats).subscribe((data)=>{
      data = JSON.parse(data);
      if(data != null){
        this.scheduledflight = data as Scheduledflight;
        console.log(this.scheduledflight.availableSeats);
      }
      else{
        alert("Scheduled Flight is not available");
      }
    });
  }

}
