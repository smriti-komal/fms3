import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewbyidavailableseatsComponent } from './viewbyidavailableseats.component';

describe('ViewbyidComponent', () => {
  let component: ViewbyidavailableseatsComponent;
  let fixture: ComponentFixture<ViewbyidavailableseatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewbyidavailableseatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewbyidavailableseatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
