import { Component, OnInit } from '@angular/core';
import { Scheduledflight } from '../../scheduledflight';
import { ScheduledflightService } from '../../scheduledflight.service';

@Component({
  selector: 'app-deletescheduledflight',
  templateUrl: './deletescheduledflight.component.html',
  styleUrls: ['./deletescheduledflight.component.css']
})
export class DeletescheduledflightComponent implements OnInit {

  availableSeats:number=0;
  msg:String;
  errorMsg:String;
  constructor(private scheduledflightService:ScheduledflightService) { }

  ngOnInit(): void {
  }

  deleteScheduledFlight(){
    console.log(this.availableSeats);

    this.scheduledflightService.deleteScheduledFlight(this.availableSeats).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
    },
    error=>{alert("Invalid Available seat");
  });
      // this.availableSeats=null;},
      // error=>{this.errorMsg=JSON.parse(error.error).message;
      //   console.log(error.error);
      //   this.msg=undefined});
  }

}
