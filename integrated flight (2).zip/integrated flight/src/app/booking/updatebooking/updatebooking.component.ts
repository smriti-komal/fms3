import { Component, OnInit } from '@angular/core';
import { Booking } from '../../booking';
import { BookingService } from '../../booking.service';

@Component({
  selector: 'app-updatebooking',
  templateUrl: './updatebooking.component.html',
  styleUrls: ['./updatebooking.component.css']
})
export class UpdatebookingComponent implements OnInit {
  booking:Booking = new Booking();
  msg:String;
  errorMsg:String;

  constructor(private bookingservice:BookingService) { }

  ngOnInit(): void {
  }
  updatebooking(){
    this.bookingservice.updatebooking(this.booking).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.booking=new Booking()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
        console.log(error.error);
        this.msg=undefined});
      }
    }
   

