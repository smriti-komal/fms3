import { Component, OnInit } from '@angular/core';
import { Booking } from '../../booking';
import { BookingService } from '../../booking.service';
import { Passenger } from '../../passenger';


@Component({
  selector: 'app-addbooking',
  templateUrl: './addbooking.component.html',
  styleUrls: ['./addbooking.component.css']
})
export class AddbookingComponent implements OnInit {
  booking:Booking=new Booking();
  passenger:Passenger=new Passenger();
  passengers:Passenger[]=[];
 
  msg:String;
  errorMsg:String;

  constructor(private bookingService:BookingService) { } 

  ngOnInit(): void {

  }
  

    addbooking(){
      
    this.bookingService.addbooking(this.booking).subscribe((data)=>{
    
    this.msg=data;
    this.errorMsg=undefined;
    this.booking= new Booking()},
    error=>{this.errorMsg=JSON.parse(error.error).message;
    console.log(error.error);
    this.msg=undefined});
    }
  }



