import { Component, OnInit } from '@angular/core';
import { Booking } from '../../booking';
import { BookingService } from '../../booking.service';

@Component({
  selector: 'app-deletebooking',
  templateUrl: './deletebooking.component.html',
  styleUrls: ['./deletebooking.component.css']
})
export class DeletebookingComponent implements OnInit { 

  bookingId:number=0;
  msg:String;
  errorMsg:String;

  constructor(private BookingService:BookingService) { }

  ngOnInit(): void {
  }
  deletebooking(){
    console.log(this.bookingId);
    this.BookingService.deletebooking(this.bookingId).subscribe((data) =>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.bookingId=null;},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
    this.msg=undefined});
      }
    }
    

