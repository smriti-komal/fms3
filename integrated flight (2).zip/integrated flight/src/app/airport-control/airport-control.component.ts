import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airport-control',
  templateUrl: './airport-control.component.html',
  styleUrls: ['./airport-control.component.css']
})
export class AirportControlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
