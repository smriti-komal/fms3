import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user1-control',
  templateUrl: './user1-control.component.html',
  styleUrls: ['./user1-control.component.css']
})
export class User1ControlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
