import { Component, OnInit } from '@angular/core';
import { AirportService } from '../../airport.service';
@Component({
  selector: 'app-deleteairport',
  templateUrl: './deleteairport.component.html',
  styleUrls: ['./deleteairport.component.css']
})
export class DeleteairportComponent implements OnInit {

  airportCode: string;
messege: string;
errormessege: string;

  constructor(private airportservice: AirportService) { }

  ngOnInit(): void {
  }
  deleteairport(){
    console.log(this.airportCode);
    this.airportservice.deleteairport(this.airportCode).subscribe((data) =>
    {
      console.log('data', data);
      this.messege = data;
      this.errormessege = undefined;
      this.airportCode = null; },
      error => {'Invalid Airport Code'});
      }}
