
export class Passenger {
    pnrNumber:number;
    passengerName:string;
    passengerAge:number;
    passengerUIN:number;
    gender:string;
    id:number;
  
}
