import { User1 } from './user1';
import { Passenger } from './passenger';
import { Flight } from './flight';
export class Booking {
    bookingId:number;
    user:User1=new User1();
    Bookingdate:string = new Date().toISOString();
    passengerList:Passenger[]=[];
    ticketCost:number;
    flight:Flight=new Flight();
    noOfPassengers:number;

    constructor(){

    }
 	
}

