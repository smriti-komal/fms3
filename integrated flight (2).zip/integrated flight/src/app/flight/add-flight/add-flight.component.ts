import { Component, OnInit } from '@angular/core';
import { Flight } from '../../flight';
import { FlightService } from '../../flight.service';

@Component({
  selector: 'app-add-flight',
  templateUrl: './add-flight.component.html',
  styleUrls: ['./add-flight.component.css']
})
export class AddFlightComponent implements OnInit {
  flight:Flight=new Flight();
  msg:String;
  errorMsg:String;
  constructor(private flightService:FlightService) { }

  ngOnInit(): void {
  }

  addFlight(){
    this.flightService.addFlight(this.flight).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.flight=new Flight()},
      error=>{alert("Invalid details");});
  }

}
