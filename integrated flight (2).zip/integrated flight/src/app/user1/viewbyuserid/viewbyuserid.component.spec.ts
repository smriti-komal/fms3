import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewbyuseridComponent } from './viewbyuserid.component';

describe('ViewbyidComponent', () => {
  let component: ViewbyuseridComponent;
  let fixture: ComponentFixture<ViewbyuseridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewbyuseridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewbyuseridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
