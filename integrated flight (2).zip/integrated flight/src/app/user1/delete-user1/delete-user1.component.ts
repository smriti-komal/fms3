import { Component, OnInit } from '@angular/core';
import {User1 } from '../../user1';
import { User1Service } from '../../user1.service'; 

@Component({
  selector: 'app-delete-user1',
  templateUrl: './delete-user1.component.html',
  styleUrls: ['./delete-user1.component.css']
})
export class DeleteUser1Component implements OnInit {
  userId:number = 0;
  msg:String;
  errorMsg:String;

  constructor(private user1Service:User1Service) { }

  ngOnInit(): void {
  }
  deleteUser1(){
    this.user1Service.deleteUser1(this.userId).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
    },
    error=>{alert("Invalid userid");
  });

}
}