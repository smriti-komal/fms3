import { Airport } from './airport';
export class Schedule {
    schedule_id:number;
    sourceAirport:Airport = new Airport();
    destinationAirport:Airport = new Airport();
    arrivalDate:Date;
    departureDate:Date;

    constructor(){
        
    }
}
